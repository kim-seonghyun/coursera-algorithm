import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.StdOut;

import java.util.ArrayList;

public class Solver {
    private SearchNode resultNode;

    //searchNode 구현함
    private static class SearchNode implements Comparable<SearchNode>{
        Board current;
        SearchNode previous;
        private int moves;
        int priorities;

        public SearchNode(Board current, SearchNode previous){
            if(previous == null){
                moves = 0;
            }else{
                moves = previous.moves++;
            }
            this.previous = previous;
            this.current = current;
            priorities = moves + current.manhattan();
        }

        public int compareTo(SearchNode o) {
            return Integer.compare(this.priorities, o.priorities);
        }
    }


    MinPQ<SearchNode> PQ;
    // find a solution to the initial board (using the A* algorithm)

    private SearchNode SolverFunction(Board initial) {
        if (initial == null) {
            throw new IllegalArgumentException();
        }
        PQ = new MinPQ<>();
        PQ.insert(new SearchNode(initial, null));
        SearchNode min = PQ.delMin();
        if (min.current.isGoal()) {
            return min;
        }
        while (true) {
            //child 추
            for (Board board : min.current.neighbors()) {
                SearchNode node = new SearchNode(board, min);

                //조상중에 같은게 있는지 체크
                SearchNode previous = node.previous;
                while(previous != null){
                    if(!min.current.equals(previous.previous.current)){
                        previous = previous.previous;
                    }else{
                        node = null;
                        break;
                    }
                }
                if(node != null){
                    PQ.insert(node);
                }

            }

            if (PQ.isEmpty()) {
                return null;
            }
            min = PQ.delMin();
            if (min.current.isGoal()) {
                return min;
            }
        }
    }

    public Solver(Board initial){
        this.resultNode = SolverFunction(initial);
    }

    // is the initial board solvable? (see below)
    public boolean isSolvable(){
        return this.resultNode != null;
    }

    // min number of moves to solve initial board; -1 if unsolvable
    public int moves(){
        if(!isSolvable()){
            return -1;
        }
        return resultNode.moves;
    }

    // sequence of boards in a shortest solution; null if unsolvable
    public Iterable<Board> solution(){
        if(!isSolvable()){
            return null;
        }
        ArrayList<Board> resultNodes = new ArrayList<>();
        while (resultNode.previous != null){
            resultNodes.add(resultNode.current);
            resultNode = resultNode.previous;
        }
        return resultNodes;
    }

    // test client (see below)
    public static void main(String[] args){
        In in = new In(args[0]);
        int n = in.readInt();
        int[][] tiles = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                tiles[i][j] = in.readInt();
            }
        }

        // solve the slider puzzle
        Board initial = new Board(tiles);
        Solver solver = new Solver(initial);
        System.out.print(solver.moves());
    }

}
